
var krms_config ={			
	'ApiUrl' : "http://patraer.com/merchantapp/api",	
	'DialogDefaultTitle' : "Control de pedisdos",
	'pushNotificationSenderid' : "409670212325",
	'APIHasKey' : "N102SyBalxsA6MhAHp8O3241vd6hR75GNI8AN-Y"
};